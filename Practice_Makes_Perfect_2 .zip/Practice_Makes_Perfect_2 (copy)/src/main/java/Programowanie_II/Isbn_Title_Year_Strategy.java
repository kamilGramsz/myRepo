package Programowanie_II;

import java.util.List;

public class Isbn_Title_Year_Strategy implements BookPrintStrategy {

    @Override
    public void print(List<Book> allBooks) {

        for (Book book : allBooks) {

            System.out.println(" Numer ISBN : " + " | " + book.getIsbn() + " | " + " Tytuł : " + " | " + book.getName() + " | " + " Rok wydania : " + " | " + book.getYear() + " | ");

        }

    }

}
