package Programowanie_II;

import java.util.List;

public class Year_Title_Isbn_Strategy implements BookPrintStrategy {


    @Override
    public void print(List<Book> allBooks) {

        for (Book book : allBooks) {

            System.out.println(" Rok wydania : " + " | " + book.getYear() + " | " + " Tytuł : " + " | " + book.getName() + " | " + " Numer ISBN : " + " | " + book.getIsbn() + " | ");

        }

    }
}
