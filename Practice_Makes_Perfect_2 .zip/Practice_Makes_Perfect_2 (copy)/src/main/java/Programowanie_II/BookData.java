package Programowanie_II;

import java.util.List;

class BookData {

    private static BookData instance = new BookData();

    BookData() {}

    private List<Programowanie_II.Book> books;

    public static BookData getInstance() {
        return instance;
    }

    public static BookData getYear(Programowanie_II.Book year){
        return BookData.getYear(year);
    }


    public List<Programowanie_II.Book> getAllBooks() {
        return books;
    }

    public void setBooks(List<Programowanie_II.Book> books) {

        this.books = books;
    }
}