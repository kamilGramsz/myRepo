package Programowanie_II;
;
import java.util.List;

public interface BookPrintStrategy {

    void print(List<Book> allBooks);


}
