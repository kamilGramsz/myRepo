package Programowanie_II;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class AppMenu {

    static BooksFunction bf = new BooksFunction();

    public static void main(String[] args) throws IOException {

        whatToDo();

    }


    public static void whatToDo() throws IOException {


        importBooks();

        int number;

        BookPrintStrategy strategy = new Year_Title_Isbn_Strategy();

        do {
            System.out.println("Witaj w ksiegarni!");
            System.out.println("Co chcesz zrobic? : \n");
            System.out.println("1. Wyświetl zbiór książek");
            System.out.println("2. Sposób wyświetlania zbioru książek");
            System.out.println("3. Kontakt");
            System.out.println("4. Wyjście");
            System.out.println("5. Wyświetl książki wydane przed podaną datą.");
            System.out.println("6. Sortowanie po roku wydania rosnąco");
            System.out.println("7. Sortowanie po tytule rosnąco"); // TODO  // wyrzucić do osobnej logiki
            System.out.println("8. Sortowanie po numerze ISBN rosnąco"); // TODO // wyrzucić do osobnej logiki

            Scanner odczyt = new Scanner(System.in);
            number = odczyt.nextInt();

            switch (number) {

                case 1:

                    strategy.print(BookData.getInstance().getAllBooks());

                    break;

                case 2:

                    System.out.println("W jaki sposób chciałbyś wyświetlić książki?");
                    System.out.println("1 : Rok, Tytuł, Numer ISBN");
                    System.out.println("2 : Numer ISBN, Tytuł, Rok");
                    System.out.println("3 : Tytuł, Rok, Numer ISBN");
                    number = odczyt.nextInt();

                    switch (number) {

                        case 1:

                            strategy = new Year_Title_Isbn_Strategy();
                            break;

                        case 2:

                            strategy = new Isbn_Title_Year_Strategy();
                            break;

                        case 3:

                            strategy = new Title_Year_Isbn_Strategy();
                            break;

                        default:

                            System.out.println("Nieprawidłowa wartość");
                    }
                    break;

                case 3:

                    System.out.println("Lokalizacja: Lodz, Adresowa 26/41 94-123");
                    System.out.println("Tel: 123-321-121");
                    System.out.println("Email: ksiegarnia@gmail.com\n");
                    break;

                case 4:

                    break;

                case 5:

                    List<Book> bookList0 = bf.booksBeforeYear(BookData.getInstance().getAllBooks());
                    strategy.print(bookList0);

                    break;

                case 6:

                    List<Book> bookList1 = bf.sortBooks(BookData.getInstance().getAllBooks());
                    strategy.print(bookList1);

                    break;

                case 7:

                    System.out.println("W budowie");

                break;

                case 8:

                    System.out.println("W budowie");

                break;

                default:

                    System.out.println("Nieprawidłowa wartość\n");

            }

        } while (number != 4);
    }

    public static List<Book> importBooks() {

        BufferedReader br;

        List<Book> books = new ArrayList<>();

        try {

            br = new BufferedReader(new InputStreamReader(
                    ClassLoader.getSystemResourceAsStream("books.csv")));

            String line = br.readLine();

            while (line != null) {
                String[] attributes = line.split(";");
                Book book = createBook(attributes);
                books.add(book);
                line = br.readLine();
            }

        } catch (IOException e) {

            e.printStackTrace();

        }

        BookData.getInstance().setBooks(books);

        return books;
    }

    private static Book createBook(String[] attributes) {

        return new Book(attributes[0], attributes[1], Integer.parseInt(attributes[2]));

    }

}

