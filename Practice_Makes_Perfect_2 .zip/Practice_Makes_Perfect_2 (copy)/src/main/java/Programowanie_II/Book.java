package Programowanie_II;

import lombok.Getter;
import lombok.Setter;

public class Book {

    @Getter
    @Setter

    private String name;

    @Getter
    @Setter

    private String isbn;

    @Getter
    @Setter

    private int year;



    @Override
    public String toString() {

        return "Book: " + name + ", " + "year: " + year
                + "\n";

    }

    public Book(String name, String isbn, int year) {

        this.name = name;

        this.isbn = isbn;

        this.year = year;
    }
}