package Programowanie_II;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;
import java.util.Scanner;

public class BooksFunction {

    Scanner scanner = new Scanner(System.in);

    public Book findISBN(List<Book> books, String isbn) {
        return books.stream().filter(book -> book.getIsbn().equals(isbn)).findFirst().get();
    }

    public List<Book> sortBooks(List<Book> books) {
        return books.stream().sorted(Comparator.comparingInt(Book::getYear)).collect(Collectors.toList());
    }

    public List<Book> sortBooks2(List<Book> books) {
        return books.stream().sorted((o1, o2) -> Integer.compare(o2.getYear(), o1.getYear())).collect(Collectors.toList());
    }

    public Book theYoungest(List<Book> books) {
        return books.stream().max((o1, o2) -> Integer.compare(o1.getYear(), o2.getYear())).get();
    }

    public Book theOldest(List<Book> books) {
        return books.stream().max((o1, o2) -> Integer.compare(o2.getYear(), o1.getYear())).get();
    }

    public List<Book> lastOnes(List<Book> books) {
        return books.stream().skip(books.size() - 2).collect(Collectors.toList());
    }


    public List<Book> booksBeforeYear(List<Book> books) throws IOException {
        int input = scanner.nextInt();
        List<Book> books1 = new ArrayList<>();
        int b = 0;
        for (int i = 0; i <= 5; i++) {
            Book book = BookData.getInstance().getAllBooks().get(i);
            if (book.getYear() < input) {
                books1.add(book);
            }
        }


        if (b == 0) {
            System.out.println("Brak wyników");

        }

        return books1;

    }
}
