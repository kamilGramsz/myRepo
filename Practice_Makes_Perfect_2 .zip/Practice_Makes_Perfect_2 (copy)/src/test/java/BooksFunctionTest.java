import Programowanie_II.BooksFunction;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import java.util.ArrayList;
import java.util.List;
import Programowanie_II.*;

public class BooksFunctionTest {

    public BooksFunction booksFunctions = new BooksFunction();

    private List<Book> books = new ArrayList<>();

    @Before
    public void init() {

        books.add(new Book("Clean Code", "0132350882", 2008));
        books.add(new Book("Effective Java", "0134685997", 2018));
        books.add(new Book("Test Driven Development", "0321146530", 2003));
        books.add(new Book("Patterns of Enterprise Application Architecture", "0321127420", 2002));
        books.add(new Book("Head First Design Patterns", "0596007124", 2004));
    }

    @Test
    public void testISBN() {

        Assert.assertEquals("0132350882", booksFunctions.findISBN(books, "0132350882").getIsbn());
        Assert.assertEquals("0596007124", booksFunctions.findISBN(books, "0596007124").getIsbn());
        Assert.assertEquals("0134685997", booksFunctions.findISBN(books, "0134685997").getIsbn());
        Assert.assertEquals("0134685997", booksFunctions.findISBN(books, "0134685997").getIsbn());
        Assert.assertNotEquals("0134685997", booksFunctions.findISBN(books, "0321127420").getIsbn());
    }

    @Test
    public void testSorting() {

        List<Book> sortedBooks = booksFunctions.sortBooks(books);
        Assert.assertEquals("0321127420", sortedBooks.get(0).getIsbn());
        Assert.assertEquals("0134685997", sortedBooks.get(sortedBooks.size()-1).getIsbn());
    }

    @Test
    public void testLastOnes() {

        List<Book> lastTwo = booksFunctions.lastOnes(books);
       Assert.assertEquals("0321127420",lastTwo.get(0).getIsbn());
       Assert.assertEquals("0596007124",lastTwo.get(1).getIsbn());
        Assert.assertEquals(2, lastTwo.size());
    }

    @Test
    public void  testSorting2() {

        List<Book> sortedBooks2 = booksFunctions.sortBooks2(books);
        Assert.assertEquals("0134685997", sortedBooks2.get(0).getIsbn());
        Assert.assertEquals("0321127420", sortedBooks2.get(sortedBooks2.size()-1).getIsbn());
    }

    @Test
    public void testTheYoungest() {

        Assert.assertEquals("0134685997",booksFunctions.theYoungest(books).getIsbn());
        Assert.assertNotEquals("0321127420", booksFunctions.theYoungest(books).getIsbn());
    }

    @Test
    public void testTheOldest() {

        Assert.assertEquals("0321127420",booksFunctions.theOldest(books).getIsbn());
        Assert.assertNotEquals("0134685997", booksFunctions.theOldest(books).getIsbn());
    }

}
