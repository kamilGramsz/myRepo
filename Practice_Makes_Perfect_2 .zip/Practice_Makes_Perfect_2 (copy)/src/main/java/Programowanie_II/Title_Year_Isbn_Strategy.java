package Programowanie_II;

import java.util.List;

public class Title_Year_Isbn_Strategy implements BookPrintStrategy {


    @Override
    public void print(List<Book> allBooks) {

        for (Book book : allBooks) {

            System.out.println(" Tytuł : " + " | " + book.getName() + " | " + " Rok wydania : " + " | " + book.getYear() + " | " + " Numer ISBN : " + " | " + book.getIsbn() + " | ");

        }


    }
}
